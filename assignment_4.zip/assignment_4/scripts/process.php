<?php

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$phoneNo = $_POST['phoneNo'];
$gender = $_POST['gender'];
$language = $_POST['language'];
$zipCode = $_POST['zipCode'];
$about = $_POST['about'];

# Backend Form Validation
if (
    strlen($name) == 0 &&
    strlen($email) == 0 &&
    strlen($password) == 0 &&
    strlen($phoneNo) == 0 &&
    strlen($gender) == 0 &&
    strlen($language) == 0 &&
    strlen($zipCode) == 0 &&
    strlen($about) == 0
) {
    header("Location: ../index.php?status=error&message=Incomplete data");
}

try {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "test";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $query = $conn->prepare(
        "INSERT INTO user (
    name, 
    email, 
    password, 
    phoneNo, 
    gender, 
    language, 
    zipCode, 
    about) VALUES (?,?,?,?,?,?,?,?)"
    );
    $query->bind_param(
        "ssssssss",
        $name,
        $email,
        $password,
        $phoneNo,
        $gender,
        $language,
        $zipCode,
        $about,
    );

    $query->execute();
    $query->close();
    $conn->close();
    header("Location: ../index.php?status=success&message=Data saved for $name");
} catch (\Throwable $th) {
    echo $th;
    header("Location: ../index.php?status=error&message=Database error connection");
}
