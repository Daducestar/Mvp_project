<?php
try {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "test";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $result = $conn->query("SELECT * FROM languages");
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $lang = $row['language'];
            echo "<option value='$lang'>$lang</option>";
        }
    } else {
        echo "<option value=''>--No Option--</option>";
    }

    $conn->close();
} catch (\Throwable $th) {
    echo "<option value=''>--Error--</option>";
}
