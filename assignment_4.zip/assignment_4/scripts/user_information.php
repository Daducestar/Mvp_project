<?php

if (isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];
} else {
    $keyword = false;
}

if (isset($_GET['by'])) {
    $by = $_GET['by'];
} else {
    $by = false;
}

try {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "test";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    if ($keyword && $by) {
        $result = $conn->query("SELECT * FROM user WHERE $by LIKE '%$keyword%'");
    } else {
        $result = $conn->query("SELECT * FROM user");
    }
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $name = $row['name'];
            $email = $row['email'];
            $phoneNo = $row['phoneNo'];
            $gender = $row['gender'];
            $language = $row['language'];
            $zipCode = $row['zipCode'];
            $about = $row['about'];
            echo "<tr>
            <td>$name</td>
            <td>$email</td>
            <td>$phoneNo</td>
            <td>$gender</td>
            <td>$language</td>
            <td>$zipCode</td>
            <td>$about</td>
            </tr>";
        }
    } else {
        echo "<td>No data</td>";
    }

    $conn->close();
} catch (\Throwable $th) {
    echo "<td>Error</td>";
}
