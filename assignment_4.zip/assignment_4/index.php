<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 4</title>
    <link rel="stylesheet" href="./static/styles.css">
</head>

<body onload="handleResponseAlert()">
    <div id="response-message" class="response-message"></div>
    <nav class="nav">
        <a href="records.php">All Records</a>
    </nav>
    <div class="form-wrapper">
        <form class="form-container" action="scripts/process.php" method="POST" onsubmit="handleSubmit(event)">
            <div class="avatar">
                <img src="./static/abdullah.jpeg" alt="avatar" />
            </div>
            <div class="field">
                <label for="name">Name:</label>
                <input type="text" name="name" id="name" placeholder="Your name">
            </div>
            <div class="field">
                <label for="email">Email:</label>
                <input type="text" name="email" id="emailphoneNo" placeholder="Your email">
            </div>
            <div class="field">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password">
            </div>
            <div class="field">
                <label for="phoneNo">Phone Number:</label>
                <input type="text" name="phoneNo" id="phoneNo">
            </div>
            <div class="field">
                <label for="gender">Gender:</label>
                <div class="opt" id="gender">
                    <label for="gender-1">Male:</label>
                    <input type="radio" name="gender" value="M" id="gender-1">
                    <label for="gender-2">Female:</label>
                    <input type="radio" name="gender" value="F" id="gender-2">
                    <label for="gender-3">Other:</label>
                    <input type="radio" name="gender" value="O" id="gender-3">
                </div>
            </div>
            <div class="field">
                <label for="language">Language:</label>
                <select name="language" id="language">
                    <option value="">--Select Language--</option>
                    <!-- Generate options from database -->
                    <?php include "scripts/language.php"; ?>
                </select>
            </div>
            <div class="field">
                <label for="zipCode">Zip Code:</label>
                <input type="number" name="zipCode" id="zipCode">
            </div>
            <div class="field">
                <label for="about">About:</label>
                <textarea name="about" id="about" rows="2" placeholder="Write about yourself..."></textarea>
            </div>
            <button type="submit">Register</button>
            <h6 class="error-display" id="error-display"></h6>
        </form>
    </div>

    <!-- Javascript -->
    <script src="./static/main.js"></script>
</body>

</html>