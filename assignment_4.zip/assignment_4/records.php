<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Records</title>
    <link rel="stylesheet" href="./static/styles.css">
</head>

<body>
    <div id="response-message" class="response-message"></div>
    <nav class="nav">
        <a href="index.php">Home</a>
    </nav>
    <div class="form-wrapper">
        <form class="form-container" action="records.php" method="GET">
            <div class="field">
                <label for="keyword">Keyword:</label>
                <input type="text" name="keyword" id="keyword" placeholder="Search...">
            </div>
            <div class="field">
                <label for="by">By:</label>
                <select name="by" id="language">
                    <option value="name">Name</option>
                    <option value="email">Email</option>
                    <option value="phoneNo">Phone Number</option>
                    <option value="gender">Gender</option>
                    <option value="language">Language</option>
                    <option value="zipCode">Zip Code</option>
                </select>
            </div>
            <button type="submit">Search</button>
        </form>
        <table class="data-container">
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Gender</th>
                <th>Language</th>
                <th>Zip Code</th>
                <th>About</th>
            </tr>
            <?php include "scripts/user_information.php"; ?>
        </table>
    </div>

    <!-- Javascript -->
    <script src="./static/main.js"></script>
</body>

</html>