<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Lecturer Navigation</title>
<link rel="stylesheet" type="text/css" href="css/5.css">
</head>

<body>
<div id="nav"> 
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="experience.php">Experience </a></li>
    <li><a href="Lecturer.php">Lecturer Navigation</a></li

  </ul>
</div> 
<?php  ?>
<div align="center">
<br>
<?php  echo'<img src="images/1.jpg" /> <br/>'?>

  <b><p align="center"> <?php echo 'BABATUNDE ISAIAH AYINLA'?></p><br/></b>
<b><u><?php echo 'ACADEMIC AND PROFESSIONAL QUALIFICATION' ?></u></b>
  <p align="center"> <?php echo 'B.sc (OOU), M.Sc (ibadan), PGD (Ilorin), PhD (Ibadan), Oracle (PL), College of Charleston, South Carolina'?></p> <br>
<b><u><?php echo 'AREA OF SPECIALIZATION' ?></u></b>
  <p align="center"> <?php echo 'Software Engineering, CyberSecurity & Machine Learning'?></p> 
  <br/>
  <hr> <br>
<?php  echo'<img src="images/akinola.jpg" /> <br/>'?>

 <b> <p align="center"> <?php echo 'AKINOLA S. OLALEKAN'?></p><br></b>
<b><u><?php echo 'ACADEMIC AND PROFESSIONAL QUALIFICATION' ?></u></b>
  <p align="center"> <?php echo 'B.sc.(Hons), M.Inf.Sc.(ibadan), PhD (Ibadan)'?></p><br>
  <b><u><?php echo 'AREA OF SPECIALIZATION' ?></u></b>
  <p align="center"> <?php echo 'Software Engineering and data Mining'?></p>

</body>
</html>
