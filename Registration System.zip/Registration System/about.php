<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="css/5.css">
</head>

<body>
  
<div id="nav">
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="experience.php">Experience Gain</a></li>
    <li><a href="Assignment/index.php">Landing Page</a></li
  </ul>
</div> 
  
    <div>
   <?php  ?>
  <h2><p align="center"><u> <?php echo 'STORY OF MY LIFE' ?></u></p></h2>
<div align="center"> <?php  echo'<img src="images/Passport.jpg"  height="200" width="200"/> <br/>'?>
</p>

<div align="center">
  <p align="center"> <?php echo 'My name is AYEGBOYIN GLORY ISREAL Ayegboyin Glory hails from Ogbomoso,Oyo State Nigeria.<br/> He finish his Secondary School level at Oyo State School of Science Ogbomoso(SOSO). <br/>He further his study at FCWM for his National Diploma in Computer  Science. <br/> He got admitted to  200L  in  Computer  Science at University of Ibadan,Ibadan,Oyo State Nigeria.  <br> '?></p><br/>
<hr> <br/>
</body>
</html>
