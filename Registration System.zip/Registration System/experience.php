<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Experience</title>
<link rel="stylesheet" type="text/css" href="css/5.css">
</head>

<body>

<div id="nav">
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="experience.php">Experience Gain</a></li>
    <li><a href="Assignment/index.php">Landing page</a></li

  </ul>
</div> 
    <?php  ?>
    <div align="center">  <br>
 <?php  echo'<img src="images/Logo.png"/> <br/>'?> <br/>
<div align="center">
<b><p align="center"> <u><?php echo 'MY EXPERIENCE SINCE I STARTED ALX SE PROGRAM' ?></u></p></b>



<br/>
<hr>
</body>
</html>
