function handleResponseAlert() {
    const params = new URLSearchParams(window.location.search);
    const status = params.get("status");
    const message = params.get("message");
    const disp = document.getElementById("response-message");
    if (status == "success") {
        disp.innerText = `${status.toUpperCase()}: ${message}`;
        disp.classList.add("show");
        setTimeout(() => disp.classList.remove("show"), 5000);
    }
}

function handleSubmit(event) {
    const name = document.getElementsByName("name")[0].value;
    const email = document.getElementsByName("email")[0].value;
    const password = document.getElementsByName("password")[0].value;
    const number = document.getElementsByName("number")[0].value;
    const gender = document.getElementsByName("gender");
    const lag= document.getElementsByName("lag")[0].value;
    const zip= document.getElementsByName("zip")[0].value;
    const about = document.getElementsByName("about")[0].value;


    if (validateRequired(name)) {
        errorDisplay("Name field is required");
        event.preventDefault();
        return false;
    }

    if (validateEmail(email)) {
        errorDisplay("Enter a valid Email Address");
        event.preventDefault();
        return false;
    }

    if (validatePassword(password)) {
        errorDisplay("Password length must be between 5 to 20 character");
        event.preventDefault();
        return false;
    }

    if (validatenumber(number)) {
        errorDisplay("Enter a valid Phone number");
        event.preventDefault();
        return false;
    }

    if (validateRadio(gender)) {
        errorDisplay("Gender field is required");
        event.preventDefault();
        return false;
    }

    if (validateRequired(lag)) {
        errorDisplay("Language field is required");
        event.preventDefault();
        return false;
    }

    if (validateZIP(zip)) {
        errorDisplay("Enter a valid ZIP/Postal Code");
        event.preventDefault();
        return false;
    }

    if (validateRequired(about)) {
        errorDisplay("About field is required");
        event.preventDefault();
        return false;
    }

    return true;

}

function validateRequired(text) {
    if (text.length > 0) return false;
    return true;
}

function validateEmail(text) {
    const pattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (pattern.test(text)) {
        return false;
    } return true;
}

function validatePassword(text) {
    if (text.length >= 5 && text.length <= 20) {
        return false;
    } return true;
}

function validatenumber(text) {
    if (text.length >= 11 && text.length <= 13) {
        return false;
    } return true;
}

function validateZIP(text) {
    if (text.length === 6) {
        return false;
    } return true;
}

function validateRadio(radios) {
    for (const radio of radios) {
        if (radio.checked) {
            return false;
        }
    }
    return true;
}

function errorDisplay(error) {
    document.getElementById("error-display").innerText = error;
}