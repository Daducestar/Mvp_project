-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 20, 2008 at 12:18 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `glory`
--

-- --------------------------------------------------------

--
-- Table structure for table `langu`
--

CREATE TABLE `langu` (
  `id` int(11) NOT NULL auto_increment,
  `p_lang` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `langu`
--

INSERT INTO `langu` (`id`, `p_lang`) VALUES
(1, 'Python'),
(2, 'PHP'),
(3, 'C'),
(4, 'C++');

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `email` varchar(22) NOT NULL,
  `password` text NOT NULL,
  `p_number` varchar(22) NOT NULL,
  `sex` text NOT NULL,
  `language` varchar(22) NOT NULL,
  `zipcode` varchar(22) NOT NULL,
  `about` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `record`
--

INSERT INTO `record` (`id`, `name`, `email`, `password`, `p_number`, `sex`, `language`, `zipcode`, `about`) VALUES
(1, 'ee', 'oyeniyi9782@gmail.com', '333', '333', 'male', 'PHP', '222', '3333'),
(2, 'ee', 'oyeniyi9782@gmail.com', 'eeee33', '33', 'male', 'PHP', '333', '333'),
(3, 'ayegboyin', 'ayegboyin@gmail.com', '1234', '081234543321', 'male', 'C', '+234', 'this is very good'),
(4, 'BOBO', 'ayegboyin@gmail.com', 'AFHIWWHEUJENFWEIFUIE', '01308929487', 'male', 'C++', '+234', 'AOEJOUIWEOE');
