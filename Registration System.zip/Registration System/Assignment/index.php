//Connection to database code
<?php 
$con = mysqli_connect('localhost', 'root');
mysqli_select_db($con, 'glory');

$query="SELECT * FROM langu";
$result =mysqli_query($con, $query);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$name = $_POST['name'];
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	$num = $_POST['number'];
	$sex = $_POST['gender'];
	$lang = $_POST['lag'];
	$zipcode = $_POST['zip'];
	$about = $_POST['about'];

	//Insertion to Database
$sql= " insert into record (name , email , password , p_number , sex , language , zipcode , about) values ('$name' ,'$email' , '$pass' ,'$num' , '$sex' , '$lang' , '$zipcode' , '$about') ";
	$res =mysqli_query($con, $sql);
	if ($res) {
		echo "SUCCESS";
	}else{
		echo "FAILLED";
	}
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
	<link rel="stylesheet" type="text/css" href="css/css.css">
    <!-- Javascript -->
    <script src="./css/main.js"></script>
</head>
<body onLoad="handleResponseAlert()">
<div id="response-message" class="response-message"></div>
    <nav class="nav">
	<div class="form-wrapper">
			//Form Registration
<h2 align="center">REGISTRATION FORM </h2> 
<div class="form-wrapper">
<form method="POST" class="form-container" action="#" onSubmit="handleSubmit(event)">    
    <div class="alert alert-info">   
 <div class="avatar">
	<img src="passport.jpg" alt="avatar"/></div>
	<div class="field">
	   <label for="name">Name:</label>
	   <input type="text" name="name" id="name" placeholder="Your Name" required="required"><br>
	</div>
	<div class="field">
	  <label for="email">Email:</label>        
	  <input type="email" name="email" placeholder="Your Email" id="email" required="required"><br>
               </div>
	<div class="field">  
	 <label for="pass"> Password: </label>    
	 <input type="Password" name="pass" id="password" required= "required"> <br>
</div>
<div class="field"> 
	<label for="number"> Phone Number: </label> 
	 <input type="text" name="number" id="number"> <br>
</div>
<div class="field">
	 <label for="gender-1">Male:</label>
	   <div class="opt" id="gender">
       <input type="radio" name="gender" value="M" id="gender-1">
       <label for="gender-2">Female:</label>
       <input type="radio" name="gender" value="F" id="gender-2">
       <label for="gender-3">Other:</label>
       <input type="radio" name="gender" value="O" id="gender-3">
       </div>
       </div>
	   <div class="field">
	<label for="lag">Language:</label>
	<select name="lag"  id="language">
	  <option value="">--Select Language--</option>
                    <!-- Generate options from database -->
		<?php while ($row=mysqli_fetch_assoc($result)) {  ?>
		<option value="<?php echo $row['p_lang']; ?>"><?php echo $row['p_lang']; ?></option>
		<?php } ?>
	</select>
	</div>
<div class="field">
  <label for="zip">Zip Code:</label>
 <input type="text" name="zip" id="zip" required= "required">
 </div>
<div class="field">
<textarea name="about" id="about" rows="2" placeholder= "Write about yourself..."></textarea>
</div>
<button type="submit">Register</button>
<h6 class="error-display" id="error-display"></h6>
	<!--<input type="submit" name="" value="Register"-->
</form> 
</div>
<a href="view.php">View Record</a>
</body>
</html>