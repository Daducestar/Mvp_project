<?php 
$con = mysqli_connect('localhost', 'root');
mysqli_select_db($con, 'glory');

if (isset($_POST['submit'])) {
	$id = $_POST['id'];

$q="SELECT * FROM record where id = $id";
$re =mysqli_query($con, $q);
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
	<link rel="stylesheet" type="text/css" href="css.css">
</head>
<body bgcolor="#99FFCC">
<form method="POST">
 <input type="text" name="id">
 <input type="submit" name="submit" value="Search">

</form>

	<table>
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Email</th>
			<th>Password</th>
			<th>Phone Number</th>
			<th>Sex</th>
			<th>Language</th>
			<th>Zip Code</th>
			<th>About</th>
		</tr>
	//Viewing Records
		<?php 

		while ($roww=mysqli_fetch_assoc($re)) { ?>
		<tr>
			<td><?php echo $roww['id']; ?></td>
			<td><?php echo $roww['name']; ?></td>
			<td><?php echo $roww['email']; ?></td>
			<td><?php echo $roww['password']; ?></td>
			<td><?php echo $roww['p_number']; ?></td>
			<td><?php echo $roww['sex']; ?></td>
			<td><?php echo $roww['language']; ?></td>
			<td><?php echo $roww['zipcode']; ?></td>
			<td><?php echo $roww['about']; ?></td>
		</tr>
			<?php }  ?>

		<tr>
			
		</tr>
		
	</table>

<?php

}else{

$query="SELECT * FROM record";
$result =mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/css.css">
</head>
<body>
<form method="POST">
 <input type="text" name="id">
 <input type="submit" name="submit" value="Search">

</form>

	<table border="3">
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Email</th>
			<th>Password</th>
			<th>Phone Number</th>
			<th>Sex</th>
			<th>Language</th>
			<th>Zip Code</th>
			<th>About</th>
		</tr>

		<?php 

		while ($row=mysqli_fetch_assoc($result)) { ?>
		<tr>
			<td><?php echo $row['id']; ?></td>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['email']; ?></td>
			<td><?php echo $row['password']; ?></td>
			<td><?php echo $row['p_number']; ?></td>
			<td><?php echo $row['sex']; ?></td>
			<td><?php echo $row['language']; ?></td>
			<td><?php echo $row['zipcode']; ?></td>
			<td><?php echo $row['about']; ?></td>
		</tr>
			<?php }  ?>

		<tr>
			
		</tr>
		
	</table>

<?php } ?>

<a href="index.php">Register</a>

</body>
</html>