<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Home Page</title>
//CSS ASPECT
<link rel="stylesheet" type="text/css" href="css/5.css">
</head>

<body>
  //head links
<div id="nav">
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="about.php">About</a></li>
    <li><a href="experience.php">Experience</a></li>
    <li><a href="Assignment/index.php">Landing Page</a></li><br>
    <marquee><h2> WELCOME TO ONLINE REGISTRATION SYSTEM </h2></marquee>
    <div align="center"> 
      <!-- nine pictures -->
        //Images
        <div class="mySlides"> <img src="images/ui.jpg" width="1100" height="500"/>
        </div>  
 <div class="mySlides"> <img src="images/computer.jpg" width="1100" height="500"/>
        </div>
          <div class="mySlides"> <img src="images/graduation.jpg" width="1100" height="500"/>
        </div>
        <div align="center"> 
    <button type="button" class="close"</button>    
                        <?php
                        $Today = date('y:m:d');
                        $new = date('l, F d, Y', strtotime($Today));
                        echo $new;
                        ?> </button> </div> </body>
    //Javascrip Code for image display
    <script type="text/javascript">
var slideIndex = 0;
Showslides();

function Showslides() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > x.length) {slideIndex = 1}
    x[slideIndex-1].style.display = "block";
    setTimeout(Showslides, 3000);
}
</script>
<div align ="center">
<!--<?php  echo'<img src="images/computer.jpg"  width="1100" height="500"/> <br/>'?>
</div>-->
    </body>
</html>
